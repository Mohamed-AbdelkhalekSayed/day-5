export interface Istudent {
    id:number,
    name:string,
    address:string,
    age:number,
    school:string,
  }